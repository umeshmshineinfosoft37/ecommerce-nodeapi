// export mongodb url
const mongoConfig= 'mongodb://localhost:27017/ecommerce-node'
module.exports = mongoConfig;
