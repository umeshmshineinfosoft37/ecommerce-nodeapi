# Full stack ecommerce online store application



#### front-end codes [click here](https://github.com/levelopers/Ecommerce-Reactjs)

#### api documentation:  [swaggerHub](https://app.swaggerhub.com/apis-docs/levelopers2/Ecommerce/1.0.0)

#### populate data: run  `node ./seed` (make sure you fill up `mongo-config` file with mongodb url)



<details>
 <summary>data model</summary>
 <p>
   
![react-native-store relational model diagram](https://user-images.githubusercontent.com/38830527/92665263-1c4cb880-f2d4-11ea-85a4-201c41517123.png)
   
</p>
</details>
